<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductSearch extends Model
{
    //

    protected $guarded = [];
}
