<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IntroSlider extends Model
{
    protected $guarded = [];
}
